package Exception_Handling;

public class EmployeeNotFoundException extends Exception{
	public EmployeeNotFoundException(String c) {
		super(c);
	}
}
