package Exception_Handling;

public class DpartmentCapacityFullException extends Exception {
	public DpartmentCapacityFullException (String c) {
		super(c);
	}
}
