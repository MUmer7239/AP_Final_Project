package Exception_Handling;

public class InvalidNumberException extends Exception {
	public InvalidNumberException(String c) {
		super(c);
	}
}
