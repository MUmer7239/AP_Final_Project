package Exception_Handling;

public class InvalidSalaryException extends Exception {
	public InvalidSalaryException(String c) {
		super(c);
	}
}
