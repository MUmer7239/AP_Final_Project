package Exception_Handling;

public class InvalidEMployeeIDException extends Exception {
	public InvalidEMployeeIDException(String c){
		super(c);
	}
}
