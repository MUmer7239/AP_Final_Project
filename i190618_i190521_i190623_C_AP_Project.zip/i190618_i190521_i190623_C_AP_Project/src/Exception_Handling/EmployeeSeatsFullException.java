package Exception_Handling;

public class EmployeeSeatsFullException extends Exception {
	public EmployeeSeatsFullException(String c) {
		super(c);
	}
}
