package Exception_Handling;

public class InvalidDepartmentException extends Exception {
	public InvalidDepartmentException(String c) {
		super(c);
	}
}
